
<?php


   if(isset($_POST['json_var'])){

	   $status=$_POST['json_var'];
   }
   
   	   $status = urldecode($status);
 




$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["firstimage"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["secondimage"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["lodg_index"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["uuid"]);
$status = json_encode($my_var);



//$manage = json_decode($status);





$jsonDecoded = json_decode($status, true);
ksort($jsonDecoded);

$csvHeader=array();
$csvData=array();
jsontocsv($jsonDecoded);


function jsontocsv($data)
{
    global $csvData,$csvHeader;
    foreach($data as $key => $value)
    {
        if(!is_array($value))
        {
            $csvData[]=$value;
            $csvHeader[]=$key;
        }
       
//		  $handle = fopen("file.csv", "w");
//		  fputcsv ($handle, $csvHeader);
//		  fputcsv ($handle, $csvData);

  
          header('Content-Disposition: attachment; filename='.basename('file.csv'));
          header('Expires: 0');
          header('Cache-Control: must-revalidate');
          header('Pragma: public');
          header('Content-Length: ' . filesize('file.csv'));
        
        }

          $handle = fopen('php://output', "w");
                  fputcsv ($handle, $csvHeader);
                  fputcsv ($handle, $csvData);

           fclose($handle);
           exit;

	//   fclose($handle);
	//	  header('Content-Type: application/octet-stream');
        //  header('Content-Disposition: attachment; filename='.basename('file.csv'));
        //  header('Expires: 0');
        //  header('Cache-Control: must-revalidate');
        //  header('Pragma: public');
        //  header('Content-Length: ' . filesize('file.csv'));
        //  readfile('file.csv');
        //  exit;
	
}

 
?>
 
