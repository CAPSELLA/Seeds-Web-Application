<!DOCTYPE html>
<html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

 
 
<style>
form {
    border: 3px solid #f1f1f1;
}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}

.wrapper {
    text-align: center;
}

.button {
    position: absolute;
    top: 50%;
}



.footerWrap {
    width:100%;
    position:fixed;
    bottom: 0px;
}
.footer {
    width:100%;
    margin:auto;

}
.footer1 {
    width:100%;
    margin:auto;
}
.footerContent {
    float:left;
    width:100%;
    background-color:green;
    padding:10px 0;
}
.footerContent1 {
    float:left;
    width:100%;
    background-color:white;
    padding:0px 0;
}
.footer p {float:left; width:100%; text-align:center; }


p.main {
    text-align: center;
}

h1 {
    font-size: 20%;

}


</style>
 </head>

<body>

  <nav class="navbar navbar-expand-lg navbar-white bg-white fixed-top" id="mainNav">
      <a class="navbar-brand" href="http://www.capsella.eu/"><img style="height:50px" src="caplogo.PNG"  ></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"  ></span>
      </button>
        
        <ul class="navbar-nav sidenav-toggler">
          <li class="nav-item">
            <a class="nav-link text-center" id="sidenavToggler">
            </a>
          </li>
        </ul>
         </nav>

<form  method="POST" >


  <div class="container">
    <label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
        <div class="wrapper">

      <button type="submit" class="btn btn-success" style="width:40%;"> Login  </button>
        </div>

 
	
	 <?php
 
$x = $_POST['uname'] ;
$y = $_POST['psw'];
$url = "https://capsella-services.madgik.di.uoa.gr:8443/capsella_authentication_service/authenticate?username=".$x."&password=".$y;

$data = array('key1' => '', 'key2' => 'value2');

// use key 'http' even if you send the request to https://...
$options = array(
    'http' => array(
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data)
    )
);

$context  = stream_context_create($options);
$result = @file_get_contents($url, false, $context);

if(!isset($result)){
	
	echo 'error';
}

if ($result === FALSE) { 

//print "error";

}
//print $result;
//var_dump($result);


$token = json_decode($result);

$token2 = $token->token;

if($token2){
	
	
   session_start();
   $_SESSION['token'] = $token2;
	
	
	//  header("location:view.php");
	  header("location:public_or_user.php");


	
}

	
 ?>	
	
  </div>
  
</form>

<div class="footerWrap">
    <div class="footer">
      <div class="footerContent">
	    <p class="main" style = "color:white";>CAPSELLA has received funding from the European Union’s Horizon 2020 research and innovation programme under grant agreement No 688813</p>
        <p class="main" style = "color:white"; >This application has been developed in the framework of the related pilot,powered by Rete Semi Rurali and Agroknow</p>

	  </div>  
	   
    <div class="footer1">	  
      <div class="footerContent1" >
           <center> 
		         <a  href="http://www.semirurali.net/" > <img   style="height:80px" src="rete.png" ></a> 
		           <a  href="http://www.agroknow.com/"> <img    style="height:80px" src="Agroknow_logo.jpg" ></a> 
		  </center> 
			</div> 	  
     </div> 	  
    </div>
</div>
</body>
</html>
