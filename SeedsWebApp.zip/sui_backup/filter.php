
<?php

session_start();

  $status1=$_GET['exp'];
  $status2=$_GET['crop'];
  $status3=$_GET['phen'];

//          echo $status1;
//          echo $status2;
//          echo $status3;

$allJsons = $_SESSION['allJsons'] ;

$out = array_values($allJsons);
$test = json_encode($out);

$json = json_decode($test, true);


for ($x = 0; $x < count($json); $x++) {


$experiment = $json[$x]["10_TYPE_OF_EXPERIMENT"];
$phen_phase = $json[$x]["16_PHENOLOGICAL_PHASE"];
$crop = $json[$x]["15_CP"];

if($phen_phase == $status3 && $crop == $status2 && $experiment == $status1){


$test_array[] = $json[$x];

//  echo $phen_phase;
//  echo  $crop;
//  echo $experiment;

}

else{


}

}

if(count($test_array) == 0){
echo "There is no dataset that matches within the chosen filters";
}

//print_r ( $test_array );





$csvHeader=array();
$csvNewLine=array();
$csvData=array();
jsontocsv($test_array);
$kk = 0 ;

function jsontocsv($data)
{

//echo "hello";

for ($x = 0; $x < count($data); $x++) {

    global $csvData,$csvHeader; 

   foreach($data[$x] as $key => $value)
    {
        if(!is_array($value))
        {
            $csvData[]=$value;
            $csvHeader[]=$key;
  

        }
       


          header('Content-Disposition: attachment; filename='.basename('file.csv'));
          header('Expires: 0');
          header('Cache-Control: must-revalidate');
          header('Pragma: public');
          header('Content-Length: ' . filesize('file.csv'));
        
      }


         

          $handle = fopen('php://output', "w");
                   if($kk == 0){
                   fputcsv ($handle, $csvHeader);
                   }
                   fputcsv ($handle, $csvData);
                   $kk=1;
                   $csvHeader=array();
                   $csvData=array();


}

           fclose($handle);
          exit;


}



?>
