<html>
 <head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 <style>
 body {
	  background-color:  	white;

 }
 
 /* Popup container - can be anything you want */
.popup {
    position: relative;
    display: inline-block;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

/* The actual popup */
.popup .popuptext {
    visibility: hidden;
    width: 160px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 8px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -80px;
}

/* Popup arrow */
.popup .popuptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}

/* Toggle this class - hide and show the popup */
.popup .show {
    visibility: visible;
    -webkit-animation: fadeIn 1s;
    animation: fadeIn 1s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
    from {opacity: 0;} 
    to {opacity: 1;}
}

@keyframes fadeIn {
    from {opacity: 0;}
    to {opacity:1 ;}
}

.footerWrap {
    width:100%;
    position:fixed;
    bottom: 0px;
}
.footer {
    width:100%;
    margin:auto;

}
.footer1 {
    width:100%;
    margin:auto;
}
.footerContent {
    float:left;
    width:100%;
    background-color:green;
    padding:10px 0;
}
.footerContent1 {
    float:left;
    width:100%;
    background-color:white;
    padding:0px 0;
}
.footer p {float:left; width:100%; text-align:center; }


p.main {
    text-align: center;
}

h1 {
    font-size: 20%;

}


 
</style>
 
 </head>
 <body  >



  <nav class="navbar navbar-expand-lg navbar-white bg-white fixed-top" id="mainNav">
      <a class="navbar-brand" href="http://www.capsella.eu/"><img style="height:50px" src="caplogo.PNG"  ></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"  ></span>
      </button>
        
        <ul class="navbar-nav sidenav-toggler">
          <li class="nav-item">
            <a class="nav-link text-center" id="sidenavToggler">
            </a>
          </li>
        </ul>
         </nav>

	
<div class="column"  >

<div class="col-md-6" style="text-align: center; padding: 10% 0px;" >

<?php
echo "

<input style=' font-size : 275%; height:100px; width:300px'  type=button class='btn btn-success btn-lg' value='Public Datasets'   <a onClick=\"window.open('view_public.php');\"></a> 

 </form>";

?>

</div>

<div class="col-md-6 "  style=" text-align:center; padding: 10% 0px;" >

<?php
	
echo "

<input  style=' font-size : 275%; height:100px; width:300px'  type=button class='btn btn-success btn-lg'   value='My Datasets'   <a onClick=\"window.open('view.php');\"></a> 

</form>";

?>
</h1>
</div>
</div>


 <script>
// When the user clicks on div, open the popup
function myFunction() {
    var popup = document.getElementById("myPopup");
    popup.classList.toggle("show");
}
</script>
<div class="footerWrap">
    <div class="footer">
      <div class="footerContent">
	    <p class="main" style = "color:white";>CAPSELLA has received funding from the European Union’s Horizon 2020 research and innovation programme under grant agreement No 688813</p>
        <p class="main" style = "color:white"; >This application has been developed in the framework of the related pilot,powered by Rete Semi Rurali and Agroknow</p>

	  </div>  
	   
    <div class="footer1">	  
      <div class="footerContent1" >
           <center> 
		         <a  href="http://www.semirurali.net/" > <img   style="height:80px" src="rete.png" ></a> 
		           <a  href="http://www.agroknow.com/"> <img    style="height:80px" src="Agroknow_logo.jpg" ></a> 
		  </center> 
			</div> 	  
     </div> 	  
    </div>
</div>
  </body>
</html>

