<html>
 <head>
 </head>
 
 <body>
 
 
 
 <?php
 session_start();
   $image = $_SESSION['image'];

  if(isset($_POST['image'])){

	   $image=$_POST['image'];
   }
 
   


			if (strlen($image) > 100) {
				echo "<img src='data:image/gif;base64,".$image."'/>";

                } else {
				 
                echo "There is no image";
				
               }
			



  ?>
  


  </body>
</html>

