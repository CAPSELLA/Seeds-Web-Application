<html>
 <head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 <style>

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 22%;
    height: 10%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 4px;
}

tr:nth-child(even) {
    background-color: ;
}




 
 #myDIV {
    width: 100%;
    text-align: center;
}
 
 body {
	  background-color:  	white;

 }
 
 #map {
        height: 20%;
		width: 20%;
      }

 .custom {
    width: 90px !important;
}

.footerWrap {
    width:100%;
    position:fixed;
    bottom: 0px;
}
.footer {
    width:100%;
    margin:auto;

}
.footer1 {
    width:100%;
    margin:auto;
}
.footerContent {
    float:left;
    width:100%;
    background-color:green;
    padding:10px 0;
}
.footerContent1 {
    float:left;
    width:100%;
    background-color:white;
    padding:0px 0;
}
.footer p {float:left; width:100%; text-align:center; }


p.main {
    text-align: center;
}

h1 {
    font-size: 20%;

}


</style>
 
 
 </head>
 <body >
 
   <nav class="navbar navbar-expand-lg navbar-white bg-white fixed-top" id="mainNav">
      <a class="navbar-brand" href="http://www.capsella.eu/"><img style="height:50px" src="caplogo.PNG"  ></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"  ></span>
      </button>
        
        <ul class="navbar-nav sidenav-toggler">
          <li class="nav-item">
            <a class="nav-link text-center" id="sidenavToggler">
            </a>
          </li>
        </ul>
         </nav>
  
<div class="row"  >

<div class="col-md-12 "  >
<div class="card mb-3"  >
<div class="card-header">
 
<i class="fa fa-file"></i>
  </i> Public Datasets info		




<button data-toggle="collapse" data-target="#spade_raw_result_filters" class="btn btn-success btn-sm custom" aria-expanded="true">Filters</button>

<div id="spade_raw_result_filters" class="collapse" aria-expanded="true" style="">


<form action='filter.php' method='get'>

 <br> <input type="radio" name="exp" value="POP. TENERO TOSCANA" checked> POP. TENERO TOSCANA<br>
  <input type="radio" name="exp" value="FRUMENTO TENERO 2016-2017"> FRUMENTO TENERO 2016-2017<br>
  <input type="radio" name="exp" value="MAIS 2018"> MAIS 2018<br><br>
  
  <input type="radio" name="crop" value="wheat" checked> Wheat<br>
  <input type="radio" name="crop" value="barley"> Barley<br>
  <input type="radio" name="crop" value="maize"> Maize<br><br>
  
  <input type="radio" name="phen" value="sowing" checked> Sowing<br>
  <input type="radio" name="phen" value="heading"> Heading<br>
  <input type="radio" name="phen" value="harvest"> Harvest<br>
  <input type="radio" name="phen" value="flowering"> Flowering<br>
  <input type="radio" name="phen" value="stem"> Stem<br>
  <input type="radio" name="phen" value="Emergence"> Emergence<br>
  <input type="radio" name="phen" value="Tillering"> Tillering<br><br>
  <input type="submit"  class="btn btn-success btn-sm custom" >

</form>





</div>  



  
</div>
<div class="list-group list-group-flush small" style="width: 100%; height: 60%; overflow-y: scroll;" >

 
 <?php


 
   session_start(); // this NEEDS TO BE AT THE TOP of the page before any output etc

   $token = $_SESSION['token'];

$uri = 'https://capsella-services.madgik.di.uoa.gr:8443/data-manager-service/datasets/getGroupDatasets';
$ch = curl_init($uri);
curl_setopt_array($ch, array(
    CURLOPT_HTTPHEADER  => array('Authorization: Bearer '.$token ,'group: seeds_app' ),
    CURLOPT_RETURNTRANSFER  =>true,
    CURLOPT_VERBOSE     => 1
));

$out = curl_exec($ch);
curl_close($ch);

$js = json_decode($out,TRUE);

var_export($js, true);




$date = $js[0]['timeCreated'] ;

$date2 = date('d/m/Y H:i:s', $date/1000);




$counter = count($js);
$list_authors1=array();
$list_authors2=array();
$list_description1=array();
$list_description2=array();


$list_images=array();
$list_images_dates=array();

$list_json=array();
$list_json_dates=array();

$list_uuid_of_images = array();

$list_base64_strings_of_images = array();



for ($x = 0; $x <= $counter; $x++) {
	
	
$link_urls = $js[$x]['endpoints'][0]['endpointUrl'];
$link_dates =$js[$x]['timeCreated'];
$link_authors =$js[$x]['author'];
$link_description =$js[$x]['description'];




$var = print_r ($link_urls,true);

$var1 = print_r ($link_dates,true);

$var2 = print_r ($link_authors,true);

$var3 = print_r ($link_description,true);





  if (strpos($var, 'Image') !== false) {

	array_push($list_images,$var);
	array_push($list_authors1,$var2);
	array_push($list_description1,$var3);

	
	$date = date('d/m/Y H:i:s', $var1/1000);
	
	array_push($list_images_dates,$date);
	

    $split = explode("/", $var);

    $split = $split[count($split)-1];
	
	array_push($list_uuid_of_images,$split);




	
    }else{
	
	array_push($list_json,$var);
	array_push($list_authors2,$var2);
	array_push($list_description2,$var3);

	
	$date = date('d/m/Y H:i:s', $var1/1000);
	
	array_push($list_json_dates,$date);

    }

 


stream_context_set_default(array(
            'ssl'                => array(
            'peer_name'          => 'generic-server',
            'verify_peer'        => FALSE,
            'verify_peer_name'   => FALSE,
            'allow_self_signed'  => TRUE
             )));

} 

	$uuid = $list_uuid_of_images[0];
	$uri2 = 'https://capsella-services.madgik.di.uoa.gr:8443/data-manager-service/datasets/getDataset/' .$uuid;
    $ch = curl_init($uri2);
    curl_setopt_array($ch, array(
    CURLOPT_HTTPHEADER  => array('Authorization: Bearer '.$token , 'group: seeds_app'),
    CURLOPT_RETURNTRANSFER  =>true,
    CURLOPT_VERBOSE     => 1
    ));
    $out = curl_exec($ch);
    curl_close($ch);
	

	
echo $list_base64_strings_of_images[0];

$count = count($list_json_dates);

for ($k = 0; $k < $count -1 ; $k++) {
	
	$d = $list_json_dates[$k];
	$j = $list_json[$k] ;
	$author = $list_authors1[$k] ;
	$description = $list_description1[$k] ;
	$test = 0 ;

	
?>



<div class="list-group-item list-group-item-action" href="#"> <div class="media">
  

 <?php
 stream_context_set_default(array(
            'ssl'                => array(
            'peer_name'          => 'generic-server',
            'verify_peer'        => FALSE,
            'verify_peer_name'   => FALSE,
            'allow_self_signed'  => TRUE
             )));
$response = file_get_contents($j,true);



$data = json_decode($response,true);

$status = json_encode($data);
 $status = substr($status, 44);
$status ="{ " . $status;
 $status = substr($status,0, -1);

$image = $data[0]['firstimage'] ;
$image2 = $data[0]['secondimage'] ;










echo "
 <table>
<form >
<tr>
<td>
<b>Survey Date:</b>".$data[0]['07_DATE_PHENOLOGICAL']."
</td>
</tr>
<tr>
<td>
<b>Date Submitted:</b>".$data[0]['01_DATE']."
</td>
</tr>
<tr>
<td>
<b> Experiment: </b>".$data[0]['10_TYPE_OF_EXPERIMENT']."
</td>
</tr>
<tr>
<td>
<b> Crop: </b>".$data[0]['15_CP']."
</td>
</tr>
<tr>
<td>
<b>Farm Name:</b>".$data[0]['02_ID_FARM']."
</td>
</tr>
<tr>
<td>
<b>Trial Number:</b>".$data[0]['08_TRIAL_N']."
</td>
</tr>
<tr>
<td>
<b>Plot Number:</b>".$data[0]['09_PLOT_N']."
</td>
</tr>
</form>
</table>

";




?>


<ul>

<form method='post' action='download_csv.php'>
<button type='submit' class='btn btn-success  btn-sm custom'  >Download</button>

  <input type='hidden' name='json_var' value=<?= urlencode($status) ?> />
  </form>
  <form method='post' action='map_test.php' target="_blank">
<button  type='submit' class='btn btn-success  btn-sm custom'  >Location</button>

  <input type='hidden' name='mapY' value= <?= $data[0]['13_LATITUDE'] ?> />
    <input type='hidden' name='mapX' value= <?= $data[0]['14_LONGITUDE'] ?> />

  </form>


  <form method='post' action='image_show.php' target="_blank">
  
<button type='submit' class='btn btn-success  btn-sm custom'  >Photo 1</button>
  <input type='hidden' name='image' value= <?=urlencode($image);?> />
 
  </form>
  
    <form method='post' action='image_show.php' target="_blank">
  
<button type='submit' class='btn btn-success  btn-sm custom'  >Photo 2</button>
  <input type='hidden' name='image' value= <?=urlencode($image2);?> />
 
  </form>


<button data-toggle="collapse" data-target="#spade_raw_result<?= $k ?>" class="btn btn-success btn-sm custom" aria-expanded="true">Open</button><div id="spade_raw_result<?= $k ?>" class="collapse" aria-expanded="true" style="">
<?php  stream_context_set_default(array(
            'ssl'                => array(
            'peer_name'          => 'generic-server',
            'verify_peer'        => FALSE,
            'verify_peer_name'   => FALSE,
            'allow_self_signed'  => TRUE
             )));
$response = file_get_contents($j,FALSE);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["firstimage"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["secondimage"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["lodg_index"]);
$status = json_encode($my_var);

$my_var = json_decode($status, true); // convert it to an array.
unset($my_var["uuid"]);
$status = json_encode($my_var);


$manage = json_decode($status,true);

$jsonData = json_encode($manage, JSON_PRETTY_PRINT);

//echo "<pre>" . $jsonData . "  </pre>";

ksort($manage);
echo "<table>\n";
foreach($manage as $key => $value){
	echo '<tr>';
	 
	       echo '<td>'.$key.'</td>';
           echo '<td>'.$value.'</td>';
	  
	  echo '</tr>';
    }
echo "</table>\n";



 ?>

 </ul>
 
 

</div>

</div>
<?php


}

?>
</div>

</div>
</div>
 
  </div>
 </div>
  

<div class="footerWrap">
    <div class="footer">
      <div class="footerContent">
	    <p class="main" style = "color:white";>CAPSELLA has received funding from the European Union’s Horizon 2020 research and innovation programme under grant agreement No 688813</p>
        <p class="main" style = "color:white"; >This application has been developed in the framework of the related pilot,powered by Rete Semi Rurali and Agroknow</p>

	  </div>  
	   
    <div class="footer1">	  
      <div class="footerContent1" >
           <center> 
		         <a  href="http://www.semirurali.net/" > <img   style="height:80px" src="rete.png" ></a> 
		           <a  href="http://www.agroknow.com/"> <img    style="height:80px" src="Agroknow_logo.jpg" ></a> 
		  </center> 
			</div> 	  
     </div> 	  
    </div>
</div>
  </body>
  
 
  
</html>

